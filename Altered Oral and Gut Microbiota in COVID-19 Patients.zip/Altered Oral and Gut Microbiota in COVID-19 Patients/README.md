Data and code for peer-review of mansucript: Altered Oral and Gut Microbiota and Its Association with SARS-CoV-2 Viral Load in Hospitalized Patients.
