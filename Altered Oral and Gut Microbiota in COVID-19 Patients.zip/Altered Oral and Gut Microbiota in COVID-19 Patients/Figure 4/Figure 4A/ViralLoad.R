
library(ggplot2)
library(tidyr)
###1 is oral, 2 is gut
dat = read.table("viralload5.txt", header=T, sep="\t")
dat[nrow(dat) + 1,] = list(0,0,0,'2')
dat[nrow(dat) + 1,] = list(0,0,0,'1')
dat[dat[,1]<=-33,]


p <- ggplot(data = dat,                # specify dataset
            aes(x ="day", y ="Ngene")) + # Age on x-, Raven on y-axis
  geom_point(pch = 1)  # plot points (pch = 1: circles, type '?pch' for other options)
p

dat2<-as_tibble(dat)
dat2

dat3<- gather(dat2, `Egene`, 'Ngene', key="gene", value="copies")
p2 = ggplot(dat3, aes(x = day, y = copies, color = gene)) + geom_point() +  geom_smooth() +
  facet_grid(SampleType~.)
p2 = p2 + theme_set(theme_bw())

p2