require(grid)
require(ggplot2)

df1 = read.table('F-ECFUlog.txt',sep = '\t',header = T)
df2 = read.table('T-ECFUlog.txt',sep = '\t',header = T)
head(df1)
head(df2)

library(ggplot2)

p1 = ggplot(data=df1)+
  geom_bar(aes(x=reorder(Term,Count),y=Count, fill=PValue), stat='identity')+
  scale_fill_gradient(expression(PValue),low="#BC3C29FF", high ="#20854EFF")+
  xlab("")+
  ylab("Coefficient")+
  scale_y_continuous(expand=c(0, 0))+
  theme(axis.text.x = element_text(angle = 270, hjust = 1, vjust = 1)) + 
  theme(
    axis.text.x=element_text(color="black",size=rel(0.5)),
    axis.text.y=element_text(color="black", size=rel(0.6)),
    axis.title.x = element_text(color="black", size=rel(1)),
    legend.text=element_text(color="black",size=rel(0.6)),
    legend.title = element_text(color="black",size=rel(1))
    # legend.position=c(0,1),legend.justification=c(-1,0)
    # legend.position="top",
  )
p1 + theme_set(theme_bw())

p2 = ggplot(data=df2)+
  geom_bar(aes(x=reorder(Term,Count),y=Count, fill=PValue), stat='identity')+
  scale_fill_gradient(expression(PValue),low="#BC3C29FF", high ="#20854EFF")+
  xlab("")+
  ylab("Coefficient")+
  scale_y_continuous(expand=c(0, 0))+
  theme(axis.text.x = element_text(angle = 270, hjust = 1, vjust = 1)) +
  theme(
    axis.text.x=element_text(color="black",size=rel(0.7)),
    axis.text.y=element_text(color="black", size=rel(0.6)),
    axis.title.x = element_text(color="black", size=rel(1)),
    legend.text=element_text(color="black",size=rel(0.6)),
    legend.title = element_text(color="black",size=rel(1))
    # legend.position=c(0,1),legend.justification=c(-1,0)
    # legend.position="top",
  )
p2 + theme_set(theme_bw())
grid.newpage()  
pushViewport(viewport(layout = grid.layout(1,5)))
vplayout <- function(Term,Count){
  viewport(layout.pos.row = Term, layout.pos.col = Count)
}
print(p1, vp = vplayout(1,1:3))   
print(p2, vp = vplayout(1,4:5))   


df3 = read.table('ECFUlog.txt',sep = '\t',header = T)
head(df3)

library(ggplot2)
p3 = ggplot(data=df3)+
  geom_bar(aes(x=reorder(Term,Count),y=Count, fill=PValue), stat='identity')+
  scale_fill_gradient(expression(PValue),low="#BC3C29FF", high ="#20854EFF")+
  xlab("")+
  ylab("Coefficient")+
  facet_grid(. ~ Sampletype, scales = 'free_x')+
  ylim(-0.48,0.48)+ 
  theme(panel.grid.major=element_line(colour=NA),
         panel.background = element_rect(fill = "transparent",colour = NA),
         plot.background = element_rect(fill = "transparent",colour = NA),
         panel.grid.minor = element_blank())+   
  theme(panel.grid.major.y = element_blank()) + 
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  theme(
    axis.text.x=element_text(color="black", size=rel(0.6)),
    axis.text.y=element_text(color="black", size=rel(0.6)),
    axis.title.x = element_text(color="black", size=rel(1)),
    legend.text=element_text(color="black",size=rel(0.6)),
    legend.title = element_text(color="black",size=rel(1))
    # legend.position=c(0,1),legend.justification=c(-1,0)
    # legend.position="top",
  )
p3 = p3 + theme_set(theme_bw())
p3