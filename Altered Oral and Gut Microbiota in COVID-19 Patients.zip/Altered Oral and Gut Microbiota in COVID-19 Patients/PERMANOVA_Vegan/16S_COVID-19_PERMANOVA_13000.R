#setwd(" ")
library(vegan)
library(EcolUtils)

###############  GroupSampleTypeDetection     #######################

group <- read.delim('mapping_all_20210313_NoS_13000.txt', sep = '\t', stringsAsFactors = FALSE)
dis <- read.delim('unweighted_unifrac_distance_matrix_NoS_13000.tsv', row.names = 1, sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)
dis1 <- as.dist(dis)
adonis_result1 <- adonis(dis1~GroupSampleTypeDetection, group, permutations = 999)
adonis_result1

set.seed(123)
result1 <- adonis.pair(dist.mat = dis1, as.factor(group$GroupSampleTypeDetection), nper = 1000, corr.method = 'fdr')
result1

###############  SampleType     #######################

group <- read.delim('mapping_all_20210313_NoS_13000.txt', sep = '\t', stringsAsFactors = FALSE)

dis <- read.delim('unweighted_unifrac_distance_matrix_NoS_13000.tsv', row.names = 1, sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)
dis1 <- as.dist(dis)
adonis_result2 <- adonis(dis1~SampleType, group, permutations = 999)
adonis_result2

set.seed(123)
result2 <- adonis.pair(dist.mat = dis1, as.factor(group$SampleType), nper = 1000, corr.method = 'fdr')
result2

###############  T severity     #######################

group <- read.delim('mapping_all_20210313_NoS_T_13000.txt', sep = '\t', stringsAsFactors = FALSE)


dis <- read.delim('unweighted_unifrac_distance_matrix.T_13000.tsv', row.names = 1, sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)
dis1 <- as.dist(dis)
adonis_result3 <- adonis(dis1~Severity, group, permutations = 999)
adonis_result3

set.seed(123)
result3 <- adonis.pair(dist.mat = dis1, as.factor(group$Severity), nper = 1000, corr.method = 'fdr')
result3


###############  T antibiotic     #######################

group <- read.delim('mapping_all_20210313_NoS_T_13000.txt', sep = '\t', stringsAsFactors = FALSE)

dis <- read.delim('unweighted_unifrac_distance_matrix.T_13000.tsv', row.names = 1, sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)
dis1 <- as.dist(dis)
adonis_result4 <- adonis(dis1~CategoryAntibiotic, group, permutations = 999)
adonis_result4

set.seed(123)
result4 <- adonis.pair(dist.mat = dis1, as.factor(group$CategoryAntibiotic), nper = 1000, corr.method = 'fdr')
result4

###############  F severity     #######################

group <- read.delim('mapping_all_20210313_NoS_F_13000.txt', sep = '\t', stringsAsFactors = FALSE)

dis <- read.delim('unweighted_unifrac_distance_matrix.F_13000.tsv', row.names = 1, sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)
dis1 <- as.dist(dis)
adonis_result5 <- adonis(dis1~Severity, group, permutations = 999)
adonis_result5

set.seed(123)
result5 <- adonis.pair(dist.mat = dis1, as.factor(group$Severity), nper = 1000, corr.method = 'fdr')
result5

###############  F antibiotic     #######################

group <- read.delim('mapping_all_20210313_NoS_F_13000.txt', sep = '\t', stringsAsFactors = FALSE)

dis <- read.delim('unweighted_unifrac_distance_matrix.F_13000.tsv', row.names = 1, sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)
dis1 <- as.dist(dis)
adonis_result6 <- adonis(dis1~CategoryAntibiotic, group, permutations = 999)
adonis_result6

set.seed(123)
result6<- adonis.pair(dist.mat = dis1, as.factor(group$CategoryAntibiotic), nper = 1000, corr.method = 'fdr')
result6

###############  T Group     #######################

group <- read.delim('mapping_all_20210313_NoS_T_13000.txt', sep = '\t', stringsAsFactors = FALSE)
dis <- read.delim('unweighted_unifrac_distance_matrix.T_13000.tsv', row.names = 1, sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)
dis1 <- as.dist(dis)
adonis_result7 <- adonis(dis1~Group, group, permutations = 999)
adonis_result7
set.seed(123)
result7 <- adonis.pair(dist.mat = dis1, as.factor(group$Group), nper = 1000, corr.method = 'fdr')
result7

###############  F Group     #######################

group <- read.delim('mapping_all_20210313_NoS_F_13000.txt', sep = '\t', stringsAsFactors = FALSE)
dis <- read.delim('unweighted_unifrac_distance_matrix.F_13000.tsv', row.names = 1, sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)
dis1 <- as.dist(dis)
adonis_result8 <- adonis(dis1~Group, group, permutations = 999)
adonis_result8

set.seed(123)
result8 <- adonis.pair(dist.mat = dis1, as.factor(group$Group), nper = 1000, corr.method = 'fdr')
result8