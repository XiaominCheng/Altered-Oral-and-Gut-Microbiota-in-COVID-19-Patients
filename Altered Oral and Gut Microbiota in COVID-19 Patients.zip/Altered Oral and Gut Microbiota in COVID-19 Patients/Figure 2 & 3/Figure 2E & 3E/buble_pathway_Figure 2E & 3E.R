
#####F

library(openxlsx)
library(ggplot2)
library(ggrepel)
dat<-read.xlsx("Group_F_function_lefse&maaslin.20201108.xlsx")
dat$p <- -log10(dat$Pvalue) 
ggplot(data = dat, aes(x = LDA, y= p)) + 
  geom_point(aes(color = Group,size=relative1),alpha=0.5,
             show.legend = F) + 
  scale_size_continuous(range=c(0,15))+
  facet_wrap(~Group) + 
  geom_text_repel(aes(label = Pathway),size = 1.5) + 
  xlim(2,3.5) + theme_bw()+
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank())


library(openxlsx)
library(ggplot2)
library(ggrepel)
dat<-read.xlsx("Figure2F.T.LefseMaaslin2.xlsx")
dat$p <- -log10(dat$Pvalue_lefse) 
ggplot(data = dat, aes(x = LDA, y= p)) + 
  geom_point(aes(color = Group,size=relative1),alpha=0.5,
             show.legend = F) + 
  scale_size_continuous(range=c(0,12))+
  facet_wrap(~Group) + 
  geom_text_repel(aes(label = Pathway),size = 1.5) + 
  xlim(2,3.25) + theme_bw()+
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank())