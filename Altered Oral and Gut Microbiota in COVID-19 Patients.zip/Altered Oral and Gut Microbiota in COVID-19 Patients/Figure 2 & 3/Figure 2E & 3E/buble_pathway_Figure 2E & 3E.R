
#####F
setwd("E:/编程学习/R语言/Rstudio工作目录/功能预测Maaslin/pathway_lefse_maaslin")

library(openxlsx)
library(ggplot2)
library(ggrepel)
dat<-read.xlsx("Group_F_function_lefse&maaslin.20201108.xlsx")
dat$p <- -log10(dat$Pvalue) 
ggplot(data = dat, aes(x = LDA, y= p)) + 
  geom_point(aes(color = Group,size=relative1),alpha=0.5,
             show.legend = F) + 
  scale_size_continuous(range=c(0,15))+
  facet_wrap(~Group) + 
  geom_text_repel(aes(label = Pathway),size = 1.5) + 
  xlim(2,3.5) + theme_bw()+
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank())
##relative1是P和H不分开，relative2是分开P和H分别计算平均相对丰度
##Pvalue是将Pvalue_lefse中最小的三个值改成了0.0001

#####T
setwd("E:/编程学习/R语言/Rstudio工作目录/功能预测Maaslin/pathway_lefse_maaslin")

library(openxlsx)
library(ggplot2)
library(ggrepel)
dat<-read.xlsx("Figure2F.T.LefseMaaslin2.xlsx")
dat$p <- -log10(dat$Pvalue_lefse) 
ggplot(data = dat, aes(x = LDA, y= p)) + 
  geom_point(aes(color = Group,size=relative1),alpha=0.5,
             show.legend = F) + 
  scale_size_continuous(range=c(0,12))+
  facet_wrap(~Group) + 
  geom_text_repel(aes(label = Pathway),size = 1.5) + 
  xlim(2,3.25) + theme_bw()+
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank())