#NoS_F
#Severity

library(ggplot2)
mapping = read.table("mapping_all_20201012_NoS_F.txt", header=T, row.names=1, sep="\t")
mapping$group=mapping$Severity

if (TRUE){
  sub_mapping = subset(mapping, group %in% c("Healthy","Non-severe","Severe"))
  sub_mapping$group  = factor(sub_mapping$group, levels=c("Healthy","Non-severe","Severe"))
}else{
  sub_mapping = mapping
}

# method = c("weighted_unifrac","unweighted_unifrac","bray_curtis")
# for(m in method){
m = "unweighted_unifrac_NoS_F"
beta = read.table(paste(m,".txt",sep=""), header=T, row.names=1, sep="\t", comment.char="", check.names = FALSE) 
idx = rownames(sub_mapping) %in% rownames(beta)
sub_mapping=sub_mapping[idx,]
sub_beta=beta[rownames(sub_mapping),rownames(sub_mapping)]
# k is dimension, 3 is recommended; eig is eigenvalues
pcoa = cmdscale(sub_beta, k=4, eig=T)
# get coordinate string, format to dataframme
points = as.data.frame(pcoa$points) 
eig = pcoa$eig
# rename group name
levels(sub_mapping$group)=c("Healthy","Non-severe","Severe")
points = cbind(points, sub_mapping$group)
colnames(points) = c("PC1", "PC2", "PC3", "PC4","group") 
p = ggplot(points, aes(x=PC1, y=PC2, color=group)) + geom_point(alpha=.7, size=1.3) +
  labs(x=paste("PCoA 1 (", format(100 * eig[1] / sum(eig), digits=4), "%)", sep=""),
       y=paste("PCoA 2 (", format(100 * eig[2] / sum(eig), digits=4), "%)", sep=""),
       title="Fecal microbiome by severity") + theme_classic() 
p = p + stat_ellipse(level=0.68)
p = p + theme(legend.position = "bottom")
p = p + theme(plot.margin = unit(c(1,3.5,1,3.5),"cm"))
p = p + scale_colour_manual(values=c('#20854EFF','#7876B1FF','#BC3C29FF'))
ggsave(paste0("Severity_", m, ".pdf", sep=""), p, width = 5, height = 3)
# }
p

#Antibiotics
mapping = read.table("mapping_all_20201012_NoS_F.txt", header=T, row.names=1, sep="\t")
mapping$group=mapping$Category.Antibiotic

if (TRUE){
  sub_mapping = subset(mapping, group %in% c("Control-N","Patient-N","Patient-Y"))
  sub_mapping$group  = factor(sub_mapping$group, levels=c("Control-N","Patient-N","Patient-Y"))
}else{
  sub_mapping = mapping
}

# method = c("weighted_unifrac","unweighted_unifrac","bray_curtis")
# for(m in method){
m = "unweighted_unifrac_NoS_F"
beta = read.table(paste(m,".txt",sep=""), header=T, row.names=1, sep="\t", comment.char="", check.names = FALSE) 
idx = rownames(sub_mapping) %in% rownames(beta)
sub_mapping=sub_mapping[idx,]
sub_beta=beta[rownames(sub_mapping),rownames(sub_mapping)]
# k is dimension, 3 is recommended; eig is eigenvalues
pcoa = cmdscale(sub_beta, k=4, eig=T)
# get coordinate string, format to dataframme
points = as.data.frame(pcoa$points) 
eig = pcoa$eig
# rename group name
levels(sub_mapping$group)=c("Healthy control","COVID-19[abx-]","COVID-19[abx+]")
points = cbind(points, sub_mapping$group)
colnames(points) = c("PC1", "PC2", "PC3", "PC4","group") 
p = ggplot(points, aes(x=PC1, y=PC2, color=group)) + geom_point(alpha=.7, size=1.3) +
  labs(x=paste("PCoA 1 (", format(100 * eig[1] / sum(eig), digits=4), "%)", sep=""),
       y=paste("PCoA 2 (", format(100 * eig[2] / sum(eig), digits=4), "%)", sep=""),
       title="Fecal microbiome by antibiotic use")  + theme_classic()
p = p + stat_ellipse(level=0.68)
p = p + theme(legend.position = "bottom")
p = p + theme(plot.margin = unit(c(1,4,1,4),"cm"))
p = p + scale_colour_manual(values=c('#20854EFF','#7876B1FF','#BC3C29FF'))
ggsave(paste0("Antibiotics_", m, ".pdf", sep=""), p, width = 5, height = 3)
# }
p

#NoS_T
#Severity

library(ggplot2)
mapping = read.table("mapping_all_20201012_NoS_T.txt", header=T, row.names=1, sep="\t")
mapping$group=mapping$Severity

if (TRUE){
  sub_mapping = subset(mapping, group %in% c("Healthy","Non-severe","Severe"))
  sub_mapping$group  = factor(sub_mapping$group, levels=c("Healthy","Non-severe","Severe"))
}else{
  sub_mapping = mapping
}

# method = c("weighted_unifrac","unweighted_unifrac","bray_curtis")
# for(m in method){
m = "unweighted_unifrac_NoS_T"
beta = read.table(paste(m,".tsv",sep=""), header=T, row.names=1, sep="\t", comment.char="", check.names = FALSE) 
idx = rownames(sub_mapping) %in% rownames(beta)
sub_mapping=sub_mapping[idx,]
sub_beta=beta[rownames(sub_mapping),rownames(sub_mapping)]
# k is dimension, 3 is recommended; eig is eigenvalues
pcoa = cmdscale(sub_beta, k=4, eig=T)
# get coordinate string, format to dataframme
points = as.data.frame(pcoa$points) 
eig = pcoa$eig
# rename group name
levels(sub_mapping$group)=c("Healthy","Non-severe","Severe")
points = cbind(points, sub_mapping$group)
colnames(points) = c("PC1", "PC2", "PC3", "PC4","group") 
p = ggplot(points, aes(x=PC1, y=PC2, color=group)) + geom_point(alpha=.7, size=1.2) +
  labs(x=paste("PCoA 1 (", format(100 * eig[1] / sum(eig), digits=4), "%)", sep=""),
       y=paste("PCoA 2 (", format(100 * eig[2] / sum(eig), digits=4), "%)", sep=""),
       title="Oral microbiome by severity") + theme_classic()
p = p + stat_ellipse(level=0.68)
p = p + theme(legend.position = "bottom")
p = p + theme(plot.margin = unit(c(1,3,1,3),"cm"))
p = p + scale_colour_manual(values=c('#0072B5FF','#7876B1FF','#BC3C29FF'))
ggsave(paste0("Severity_", m, ".pdf", sep=""), p, width = 5, height = 3)
# }
p

#Antibiotics
mapping = read.table("mapping_all_20201012_NoS_T.txt", header=T, row.names=1, sep="\t")
mapping$group=mapping$Category.Antibiotic

if (TRUE){
  sub_mapping = subset(mapping, group %in% c("Control-N","Patient-N","Patient-Y"))
  sub_mapping$group  = factor(sub_mapping$group, levels=c("Control-N","Patient-N","Patient-Y"))
}else{
  sub_mapping = mapping
}
# method = c("weighted_unifrac","unweighted_unifrac","bray_curtis")
# for(m in method){
m = "unweighted_unifrac_NoS_T"
beta = read.table(paste(m,".tsv",sep=""), header=T, row.names=1, sep="\t", comment.char="", check.names = FALSE) 
idx = rownames(sub_mapping) %in% rownames(beta)
sub_mapping=sub_mapping[idx,]
sub_beta=beta[rownames(sub_mapping),rownames(sub_mapping)]
# k is dimension, 3 is recommended; eig is eigenvalues
pcoa = cmdscale(sub_beta, k=4, eig=T)
# get coordinate string, format to dataframme
points = as.data.frame(pcoa$points) 
eig = pcoa$eig
# rename group name
levels(sub_mapping$group)=c("Healthy control","COVID-19[abx-]","COVID-19[abx+]")
points = cbind(points, sub_mapping$group)
colnames(points) = c("PC1", "PC2", "PC3", "PC4","group") 
p = ggplot(points, aes(x=PC1, y=PC2, color=group)) + geom_point(alpha=.7, size=1.2) +
  labs(x=paste("PCoA 1 (", format(100 * eig[1] / sum(eig), digits=4), "%)", sep=""),
       y=paste("PCoA 2 (", format(100 * eig[2] / sum(eig), digits=4), "%)", sep=""),
       title="Oral microbiome by antibiotic use") + theme_classic()
p = p + stat_ellipse(level=0.68)
p = p + theme(legend.position = "bottom")
p = p + theme(plot.margin = unit(c(1,3.5,1,3.5),"cm"))
p = p + scale_colour_manual(values=c('#0072B5FF','#7876B1FF','#BC3C29FF'))
ggsave(paste0("Antibiotics_", m, ".pdf", sep=""), p, width = 5, height = 3)
# }
p
