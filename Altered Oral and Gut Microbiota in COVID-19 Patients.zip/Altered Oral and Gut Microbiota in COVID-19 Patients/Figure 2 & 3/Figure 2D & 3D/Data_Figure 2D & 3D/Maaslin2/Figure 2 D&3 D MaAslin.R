library(Maaslin2)

###Fecal sample
NoS_F_input_data <- read.table("otu_table.GenusSpecies.relative.FORMAASLIN_F.txt", header=T, sep = "\t",row.names = 1, stringsAsFactors = FALSE)
NoS_F_input_metadata <-read.table("mapping_all.txt", header=T, sep = "\t",row.names = 1, stringsAsFactors = FALSE)

fit_data <- Maaslin2(
  NoS_F_input_data, NoS_F_input_metadata, 'NoS_F.output_Masslin', transform = "AST",
  fixed_effects = c('Group','Detection','Sex','age','Antibiotic','Severity'),
  random_effects = c('PatientID'),
  normalization = 'NONE',
  min_abundance = 0.0005,
  min_prevalence = 0.1,
  standardize = FALSE)

###Throat swab
NoS_T_input_data <- read.table("otu_table.GenusSpecies.relative.FORMAASLIN_T.txt", header=T, sep = "\t",row.names = 1, stringsAsFactors = FALSE)
NoS_T_input_metadata <-read.table("mapping_all.txt", header=T, sep = "\t",row.names = 1, stringsAsFactors = FALSE)

fit_data <- Maaslin2(
  NoS_T_input_data, NoS_T_input_metadata, 'NoS_T.output_Masslin', transform = "AST",
  fixed_effects = c('Group','Detection','Sex','age','Antibiotic','Severity'),
  random_effects = c('PatientID'),
  normalization = 'NONE',
  min_abundance = 0.0005,
  min_prevalence = 0.1,
  standardize = FALSE)
