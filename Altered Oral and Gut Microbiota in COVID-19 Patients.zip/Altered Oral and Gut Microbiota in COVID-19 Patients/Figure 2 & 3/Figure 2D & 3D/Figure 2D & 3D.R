###T
df = read.table('Throat swab.txt',sep = '\t',header = T)
head(df)

library(ggplot2)

ggplot(df,aes(x = reorder(Taxonomy,LDA),y=LDA,fill = Group)) + 
  geom_bar(stat = 'identity',colour = 'black',width = 0.9,position = position_dodge(0.7))+ 
  xlab('') + ylab('LDA') + coord_flip() + 
  theme_bw()   + 
  theme(panel.grid.major.y = element_blank(),panel.grid.major.x = element_blank()) +
  theme(axis.text.y =  element_blank(),axis.ticks = element_blank(),
        axis.text.x = element_text(face = 'bold'),axis.title.x = element_text(face='bold')) + 
  theme(panel.border = element_blank())+
  geom_text(aes(y = ifelse(df$LDA >0,-0.1,0.1),label=Taxonomy),fontface=4,size=1,hjust = ifelse(df$LDA>0,1,0))


df=df[order(df[,2],df[,3]),] 
head(df)

df$Taxonomy = factor(df$Taxonomy,levels = as.character(df$Taxonomy))

df$Taxonomy = factor(df$Taxonomy,levels = as.character(df$Taxonomy))
ggplot(df,aes(x = Taxonomy,y=LDA,fill = Group)) + 
  geom_bar(stat = 'identity',colour = 'black',width = 0.9,position = position_dodge(0.7))+ 
  xlab('') + ylab('LDA') + coord_flip() + 
  theme_bw()   + 
  theme(panel.grid.major.y = element_blank(),panel.grid.major.x = element_blank()) +
  theme(axis.text.y = element_blank(),axis.ticks = element_blank(),
        axis.text.x = element_text(face = 'bold'),axis.title.x = element_text(face='bold')) + 
  theme(panel.border = element_blank())+
  geom_text(aes(y = ifelse(df$LDA >0,-0.1,0.1),label=Taxonomy),fontface=4,size=1,hjust = ifelse(df$LDA>0,1,0))

df[df$Group=='P',3] = 0 - df[df$Group=='P',3]
head(df)

df$Taxonomy = factor(df$Taxonomy,levels = as.character(df$Taxonomy))

p <- ggplot(df,aes(x = Taxonomy,y=LDA,fill = Group)) + 
  geom_bar(stat = 'identity',colour = 'black',width = 1,position = position_dodge(0.7))+ 
  xlab('') + ylab('log10(LDA score)') + coord_flip() + 
  theme_bw()   + 
  scale_fill_manual(values=c('#0072B5FF','#BC3C29FF')) +
  theme(panel.grid.major=element_blank(),panel.grid.minor=element_blank()) + 
  theme(axis.text.y = element_blank(),axis.ticks = element_blank(),
        axis.text.x = element_text(face = 'bold'),axis.title.x = element_text(face='bold'),plot.margin = unit(c(1,1,1,2),"cm")) +
  theme(panel.border = element_blank()) +
  theme(axis.line.x = element_line(size = 1)) +
  theme(axis.ticks.x = element_line(size = 1)) +
  geom_text(aes(y = ifelse(df$LDA >0,-0.1,0.1),label=Taxonomy),fontface=4,size=2,hjust = ifelse(df$LDA>0,1,0))
p


###F

df = read.table('Fecal sample.txt',sep = '\t',header = T)
head(df)

library(ggplot2)

ggplot(df,aes(x = reorder(Taxonomy,LDA),y=LDA,fill = Group)) + 
  geom_bar(stat = 'identity',colour = 'black',width = 0.9,position = position_dodge(0.7))+ 
  xlab('') + ylab('LDA') + coord_flip() + 
  theme_bw()   + 
  theme(panel.grid.major.y = element_blank(),panel.grid.major.x = element_blank()) +
  theme(axis.text.y =  element_blank(),axis.ticks = element_blank(),
        axis.text.x = element_text(face = 'bold'),axis.title.x = element_text(face='bold')) + 
  theme(panel.border = element_blank())+
  geom_text(aes(y = ifelse(df$LDA >0,-0.1,0.1),label=Taxonomy),fontface=4,size=1,hjust = ifelse(df$LDA>0,1,0))


df=df[order(df[,2],df[,3]),] 
head(df)

df$Taxonomy = factor(df$Taxonomy,levels = as.character(df$Taxonomy))

df$Taxonomy = factor(df$Taxonomy,levels = as.character(df$Taxonomy))
ggplot(df,aes(x = Taxonomy,y=LDA,fill = Group)) + 
  geom_bar(stat = 'identity',colour = 'black',width = 0.9,position = position_dodge(0.7))+ 
  xlab('') + ylab('LDA') + coord_flip() + 
  theme_bw()   + 
  theme(panel.grid.major.y = element_blank(),panel.grid.major.x = element_blank()) +
  theme(axis.text.y = element_blank(),axis.ticks = element_blank(),
        axis.text.x = element_text(face = 'bold'),axis.title.x = element_text(face='bold')) + 
  theme(panel.border = element_blank())+
  geom_text(aes(y = ifelse(df$LDA >0,-0.1,0.1),label=Taxonomy),fontface=4,size=1,hjust = ifelse(df$LDA>0,1,0))

df[df$Group=='P',3] = 0 - df[df$Group=='P',3]
head(df)

df$Taxonomy = factor(df$Taxonomy,levels = as.character(df$Taxonomy))

p <- ggplot(df,aes(x = Taxonomy,y=LDA,fill = Group)) + 
  geom_bar(stat = 'identity',colour = 'black',width = 1,position = position_dodge(0.7))+ 
  xlab('') + ylab('log10(LDA score)') + coord_flip() + 
  theme_bw()   + 
  scale_fill_manual(values=c('#20854EFF','#BC3C29FF')) +
  theme(panel.grid.major=element_blank(),panel.grid.minor=element_blank()) + 
  theme(axis.text.y = element_blank(),axis.ticks = element_blank(),
        axis.text.x = element_text(face = 'bold'),axis.title.x = element_text(face='bold'),plot.margin = unit(c(1,1,1,2),"cm")) +
  theme(panel.border = element_blank()) +
  theme(axis.line.x = element_line(size = 1)) +
  theme(axis.ticks.x = element_line(size = 1)) +
  geom_text(aes(y = ifelse(df$LDA >0,-0.1,0.1),label=Taxonomy),fontface=4,size=2,hjust = ifelse(df$LDA>0,1,0))
p

